//Mude o nome para o nome que voc� definiu para o arquivo.h
#include "Main.h"

using namespace System;
using namespace System::Windows::Forms;
void main(array<String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	//Mude o Main com o nome do arquivo que voc� definiu no arquivo.h
	//Mude Teste1 para o nome do Seu projeto
	Contadordenotas::Main winForm;
	Application::Run(% winForm);
}