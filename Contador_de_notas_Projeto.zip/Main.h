#pragma once
#include <string>
#include <cstdlib>

namespace Contadordenotas {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Diagnostics;


	/// <summary>
	/// Sum�rio para Main
	/// </summary>
	public ref class Main : public System::Windows::Forms::Form
	{
	public:
		Main(void)
		{
			InitializeComponent();
			//
			//TODO: Adicione o c�digo do construtor aqui
			//
		}

	protected:
		/// <summary>
		/// Limpar os recursos que est�o sendo usados.
		/// </summary>
		~Main()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ tri1;
	private: System::Windows::Forms::TextBox^ tri2;
	private: System::Windows::Forms::TextBox^ tri3;
	private: System::Windows::Forms::TextBox^ Valor_passar;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;

	private: System::Windows::Forms::Button^ btr_calc;
	private: System::Windows::Forms::LinkLabel^ linkLabel1;
	private: System::Windows::Forms::Label^ nota_txt;

	private:

	private:





	protected:




	protected:

	protected:





	private:
		/// <summary>
		/// Vari�vel de designer necess�ria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necess�rio para suporte ao Designer - n�o modifique 
		/// o conte�do deste m�todo com o editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Main::typeid));
			this->tri1 = (gcnew System::Windows::Forms::TextBox());
			this->tri2 = (gcnew System::Windows::Forms::TextBox());
			this->tri3 = (gcnew System::Windows::Forms::TextBox());
			this->Valor_passar = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btr_calc = (gcnew System::Windows::Forms::Button());
			this->linkLabel1 = (gcnew System::Windows::Forms::LinkLabel());
			this->nota_txt = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// tri1
			// 
			this->tri1->Location = System::Drawing::Point(12, 63);
			this->tri1->Margin = System::Windows::Forms::Padding(3, 20, 3, 3);
			this->tri1->Name = L"tri1";
			this->tri1->Size = System::Drawing::Size(171, 20);
			this->tri1->TabIndex = 0;
			this->tri1->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->tri1->TextChanged += gcnew System::EventHandler(this, &Main::tri1_TextChanged);
			// 
			// tri2
			// 
			this->tri2->Location = System::Drawing::Point(12, 106);
			this->tri2->Margin = System::Windows::Forms::Padding(3, 20, 3, 3);
			this->tri2->Name = L"tri2";
			this->tri2->Size = System::Drawing::Size(171, 20);
			this->tri2->TabIndex = 1;
			this->tri2->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->tri2->TextChanged += gcnew System::EventHandler(this, &Main::tri2_TextChanged);
			// 
			// tri3
			// 
			this->tri3->Location = System::Drawing::Point(12, 149);
			this->tri3->Margin = System::Windows::Forms::Padding(3, 20, 3, 3);
			this->tri3->Name = L"tri3";
			this->tri3->Size = System::Drawing::Size(171, 20);
			this->tri3->TabIndex = 2;
			this->tri3->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->tri3->TextChanged += gcnew System::EventHandler(this, &Main::tri3_TextChanged);
			// 
			// Valor_passar
			// 
			this->Valor_passar->BackColor = System::Drawing::SystemColors::Window;
			this->Valor_passar->ForeColor = System::Drawing::SystemColors::WindowText;
			this->Valor_passar->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->Valor_passar->Location = System::Drawing::Point(12, 20);
			this->Valor_passar->Name = L"Valor_passar";
			this->Valor_passar->Size = System::Drawing::Size(122, 20);
			this->Valor_passar->TabIndex = 3;
			this->Valor_passar->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->Valor_passar->TextChanged += gcnew System::EventHandler(this, &Main::Valor_passar_TextChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(12, 4);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(149, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Valor Minimo para passar";
			this->label1->Click += gcnew System::EventHandler(this, &Main::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 48);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(108, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Primeiro Trimestre";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 92);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(113, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Segundo Trimestre";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(12, 135);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(110, 13);
			this->label4->TabIndex = 7;
			this->label4->Text = L"Terceiro Trimestre";
			// 
			// btr_calc
			// 
			this->btr_calc->BackColor = System::Drawing::Color::Lime;
			this->btr_calc->Cursor = System::Windows::Forms::Cursors::Hand;
			this->btr_calc->Location = System::Drawing::Point(241, 48);
			this->btr_calc->Name = L"btr_calc";
			this->btr_calc->Size = System::Drawing::Size(75, 87);
			this->btr_calc->TabIndex = 9;
			this->btr_calc->Text = L"Calcular";
			this->btr_calc->UseVisualStyleBackColor = false;
			this->btr_calc->Click += gcnew System::EventHandler(this, &Main::btr_calc_Click);
			// 
			// linkLabel1
			// 
			this->linkLabel1->AutoSize = true;
			this->linkLabel1->Location = System::Drawing::Point(294, 289);
			this->linkLabel1->Name = L"linkLabel1";
			this->linkLabel1->Size = System::Drawing::Size(38, 13);
			this->linkLabel1->TabIndex = 10;
			this->linkLabel1->TabStop = true;
			this->linkLabel1->Text = L"Github";
			this->linkLabel1->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Main::linkLabel1_LinkClicked);
			// 
			// nota_txt
			// 
			this->nota_txt->AutoSize = true;
			this->nota_txt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->nota_txt->Location = System::Drawing::Point(58, 235);
			this->nota_txt->Name = L"nota_txt";
			this->nota_txt->Size = System::Drawing::Size(202, 24);
			this->nota_txt->TabIndex = 11;
			this->nota_txt->Text = L"SUAS NOTAS AQUI!";
			// 
			// Main
			// 
			this->AccessibleDescription = L"Calcule as sua notas mais rapido";
			this->AccessibleName = L"Calculadora de notas";
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->AutoValidate = System::Windows::Forms::AutoValidate::EnablePreventFocusChange;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->CausesValidation = false;
			this->ClientSize = System::Drawing::Size(344, 309);
			this->Controls->Add(this->nota_txt);
			this->Controls->Add(this->linkLabel1);
			this->Controls->Add(this->btr_calc);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Valor_passar);
			this->Controls->Add(this->tri3);
			this->Controls->Add(this->tri2);
			this->Controls->Add(this->tri1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"Main";
			this->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Calculadora de notas";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void tri1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void tri2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void tri3_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void Valor_passar_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void btr_calc_Click(System::Object^ sender, System::EventArgs^ e) {
		if (Valor_passar->Text->Length == 0 || tri1->Text->Length == 0 || tri2->Text->Length == 0 || tri3->Text->Length == 0) {
			MessageBox::Show("Preencha todas as Caixas com as notas Primeiro!!", "Aviso!!", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		else {
			int valor_passar_convertion = System::Convert::ToInt16(Valor_passar->Text);
			int tri1_convertion = System::Convert::ToInt16(tri1->Text);
			int tri2_convertion = System::Convert::ToInt16(tri2->Text);
			int tri3_convertion = System::Convert::ToInt16(tri3->Text);
			int result = tri1_convertion + tri2_convertion + tri3_convertion - valor_passar_convertion;

			std::string resultado = std::to_string(result);
			System::String^ resultado_msg = gcnew System::String(resultado.c_str());

			nota_txt->Text = "Voc� tem que tirar: " + resultado_msg;
		}

		
	}
	private: System::Void linkLabel1_LinkClicked(System::Object^ sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^ e) {
		Process::Start("https://github.com/GabrielBrigola22");
	}
};
}
